'use strict';

const favbtn=document.querySelector('.fav');

favbtn.addEventListener('click',function(){
    document.querySelector('.fav').style.backgroundColor='red';
})