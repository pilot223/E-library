EMAIL_USE_TLS=True
EMAIL_HOST='smtp.gmail.com'
EMAIL_HOST_USER='elibrarybookalicious@gmail.com'
EMAIL_HOST_PASSWORD='Bookalicious@42'
EMAIL_PORT=587