from django.contrib import admin
from book_copy import models

# Register your models here.
admin.site.register(models.Book)
